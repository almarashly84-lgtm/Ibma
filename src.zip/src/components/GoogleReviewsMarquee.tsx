import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Star, ExternalLink, Quote, Sparkles, CheckCircle2 } from 'lucide-react';

interface ReviewItem {
  id: string;
  name: string;
  role: { ar: string; en: string; fr: string };
  rating: number;
  date: { ar: string; en: string; fr: string };
  text: { ar: string; en: string; fr: string };
  avatar: string;
}

const REVIEWS_DATA: ReviewItem[] = [
  {
    id: '1',
    name: 'Mohamad Al-Halabi',
    role: { ar: 'صاحب شركة في أوتاوا', en: 'Business Owner in Ottawa', fr: 'Propriétaire d\'entreprise à Ottawa' },
    rating: 5,
    date: { ar: 'منذ شهر', en: '1 month ago', fr: 'Il y a 1 mois' },
    text: {
      ar: 'المحاسب إبراهيم في IBMA Accounting قمة في الاحتراف والأمانة! قام بإعداد ضرائب الشركة وضريبة HST وتقديمها إلى CRA بسرعة وسلاسة مع استرجاع مالي ممتاز.',
      en: 'Ibrahim at IBMA Accounting is outstanding! He handled my corporate taxes and HST filings quickly and efficiently. Always accessible, honest, and provides the best financial advice.',
      fr: 'Ibrahim chez IBMA Accounting est exceptionnel! Il a géré mes impôts corporatifs et déclarations de TPS/TVH avec rapidité et rigueur professionnelle.'
    },
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: '2',
    name: 'Sarah Thompson',
    role: { ar: 'مستفيدة من إقرار ضريبي شخصي', en: 'Personal Tax Client', fr: 'Cliente Impôt Personnel' },
    rating: 5,
    date: { ar: 'منذ شهرين', en: '2 months ago', fr: 'Il y a 2 mois' },
    text: {
      ar: 'أفضل مكتب محاسبة وضرائب في أوتاوا ونيبيان! إبراهيم ساعدني في تحصيل الحد الأقصى من استرداد الضرائب وحل ملف معلق مع CRA بدون أي تعقيد. شكراً جزيلاً!',
      en: 'Best tax accountant in Ottawa & Nepean! Ibrahim helped me maximize my refund and resolved an old CRA review with zero hassle. Professional and very reasonably priced.',
      fr: 'Meilleur comptable fiscaliste à Ottawa/Nepean! Ibrahim m\'a aidé à maximiser mon remboursement avec un tarif très raisonnable.'
    },
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: '3',
    name: 'Ahmad El-Masri',
    role: { ar: 'عمل حر - مقاولات عامة', en: 'Self-Employed Contractor', fr: 'Entrepreneur Indépendant' },
    rating: 5,
    date: { ar: 'منذ 3 أسابيع', en: '3 weeks ago', fr: 'Il y a 3 semaines' },
    text: {
      ar: 'خدمة ممتازة واحترافية عالية جداً! الأخ إبراهيم ساعدني في تسجيل أعمالي ومسك الدفاتر الضريبية وWSIB بدقة متناهية، أنصح كل أصحاب الأعمال بالتعامل مع مكتب IBMA.',
      en: 'Outstanding service and highest professionalism! Ibrahim helped me register my business, manage bookkeeping, and WSIB with extreme precision. Highly recommended!',
      fr: 'Service exceptionnel! Ibrahim m\'a guidé dans l\'enregistrement de mon entreprise et la tenue de livres comptables avec grande précision.'
    },
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: '4',
    name: 'David Tremblay',
    role: { ar: 'استشارات مالية وشركات', en: 'Corporate Client', fr: 'Client Corporatif' },
    rating: 5,
    date: { ar: 'منذ أسبوعين', en: '2 weeks ago', fr: 'Il y a 2 semaines' },
    text: {
      ar: 'خدمة استثنائية! إبراهيم يتمتع بخبرة واسعة وموثوقة في قوانين الضرائب الكندية للشركات. الدقة في المواعيد والشفافية التامة ميزتان نادرتان تجدهما هنا.',
      en: 'Exceptional service! Ibrahim is very knowledgeable and meticulous with corporate returns and year-end reporting. Transparent and always on schedule.',
      fr: 'Un service exceptionnel! Ibrahim est très compétent et rigoureux dans la préparation des déclarations d\'impôts corporatives. Merci IBMA!'
    },
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: '5',
    name: 'Fatima Al-Zahraa',
    role: { ar: 'ضرائب عائلية وشخصية', en: 'Family Tax Client', fr: 'Impôts Particuliers et Famille' },
    rating: 5,
    date: { ar: 'منذ شهر', en: '1 month ago', fr: 'Il y a 1 mois' },
    text: {
      ar: 'تعامل راقٍ وأمانة مطلقة وسرعة في إنجاز الإقرارات الضريبية واسترداد مبالغ ممتازة من مصلحة الضرائب CRA. المحاسب إبراهيم خبير ومتعاون لأقصى درجة.',
      en: 'Great communication, absolute integrity, and fast filing with maximum refund from CRA. Accountant Ibrahim is polite, highly experienced, and supportive.',
      fr: 'Excellente communication, intégrité absolue et remboursement maximal de l\'ARC. Ibrahim est un expert de confiance.'
    },
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: '6',
    name: 'Michael Chen',
    role: { ar: 'تجارة إلكترونية وأعمال حرة', en: 'E-commerce & Freelance', fr: 'E-commerce & Freelance' },
    rating: 5,
    date: { ar: 'منذ شهرين', en: '2 months ago', fr: 'Il y a 2 mois' },
    text: {
      ar: 'سريع ودقيق ومطلع على كافة الإعفاءات الضريبية الكندية القانونية. وفر عليّ مبالغ كبيرة في تقارير الضرائب، وأنصح أي شخص يبحث عن راحة البال بالتعامل معه.',
      en: 'Fast, accurate, and completely up to date with Canadian tax deductions and laws. Saved me significant money on corporate filing. Peace of mind guaranteed!',
      fr: 'Rapide, précis et maîtrise parfaitement la législation fiscale canadienne. M\'a fait économiser beaucoup sur mes déclarations.'
    },
    avatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=150&auto=format&fit=crop&q=80'
  }
];

export const GoogleReviewsMarquee: React.FC = () => {
  const { language, dir } = useLanguage();
  const [isPaused, setIsPaused] = useState(false);

  const googleShareUrl = 'https://share.google/yn0yKvLw7xZeVxkUa';

  return (
    <section id="reviews" className="py-12 sm:py-16 bg-[#070A0F] border-t border-slate-800/80 relative overflow-hidden">
      {/* Background Subtle Ambient Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[300px] bg-amber-500/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-8 sm:mb-10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-center md:text-start">
          
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold uppercase tracking-wider mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{language === 'ar' ? 'تقييمات Google المعتمدة (5.0 / 5.0)' : 'Verified Google Reviews (5.0 / 5.0)'}</span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center justify-center md:justify-start gap-2.5">
              <span>{language === 'ar' ? 'ماذا يقول عملاؤنا عن IBMA Accounting' : language === 'fr' ? 'Ce que disent nos clients' : 'What Our Clients Say About Us'}</span>
            </h2>

            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl">
              {language === 'ar'
                ? 'تقييمات حقيقية وإيجابية بنسبة 100% من أصحاب الشركات والأفراد في كندا'
                : '100% genuine positive feedback from business owners and individuals across Canada'}
            </p>
          </div>

          {/* Direct Link to Google Reviews Official Page */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1 bg-[#101726] px-3.5 py-2 rounded-xl border border-amber-500/30">
              <div className="flex text-amber-400">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                ))}
              </div>
              <span className="text-xs font-black text-white ms-1.5">5.0</span>
            </div>

            <a
              href={googleShareUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold text-black bg-gradient-to-r from-amber-400 to-yellow-400 hover:from-amber-300 hover:to-amber-500 shadow-md shadow-amber-500/20 transition-all hover:scale-105 active:scale-95"
            >
              <span>{language === 'ar' ? 'عرض على Google' : 'View on Google'}</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>

        </div>
      </div>

      {/* Infinite Scrolling Marquee Track (Moving Right to Left smoothly) */}
      <div 
        className="relative w-full overflow-hidden select-none py-2"
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
        onTouchStart={() => setIsPaused(true)}
        onTouchEnd={() => setIsPaused(false)}
      >
        <div 
          className={`flex gap-4 sm:gap-6 w-max ${isPaused ? 'animate-none' : 'animate-marquee'}`}
          style={{ animationDuration: '35s' }}
        >
          {/* Double the list to ensure smooth infinite loop without blank gaps */}
          {[...REVIEWS_DATA, ...REVIEWS_DATA].map((review, idx) => (
            <div
              key={`${review.id}-${idx}`}
              className="w-[280px] sm:w-[350px] p-4 sm:p-5 rounded-2xl bg-[#0F141F] border border-slate-800 hover:border-amber-400/80 transition-all duration-300 shadow-xl shadow-black/40 flex flex-col justify-between shrink-0 hover:-translate-y-1"
            >
              <div>
                {/* Header: User Avatar + Name + Rating */}
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={review.avatar}
                      alt={review.name}
                      className="w-10 h-10 rounded-full object-cover border border-amber-500/40"
                    />
                    <div>
                      <h4 className="text-sm font-bold text-white leading-tight">
                        {review.name}
                      </h4>
                      <span className="text-[11px] text-slate-400 block mt-0.5">
                        {review.role[language]}
                      </span>
                    </div>
                  </div>

                  {/* Google "G" Badge */}
                  <div className="w-7 h-7 rounded-full bg-white/10 border border-white/20 flex items-center justify-center p-1 shrink-0" title="Google Verified Review">
                    <svg className="w-4 h-4" viewBox="0 0 24 24">
                      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                      <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                    </svg>
                  </div>
                </div>

                {/* Stars */}
                <div className="flex items-center gap-1 mb-2.5">
                  {[...Array(review.rating)].map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                  ))}
                  <span className="text-[11px] text-slate-400 ms-2 font-mono">
                    {review.date[language]}
                  </span>
                </div>

                {/* Review Text */}
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed line-clamp-3">
                  "{review.text[language]}"
                </p>
              </div>

              {/* Verified Badge */}
              <div className="pt-2.5 mt-2.5 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-emerald-400 font-semibold">
                <span className="flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                  <span>{language === 'ar' ? 'تقييم موثق من Google' : 'Google Verified Review'}</span>
                </span>
                <span className="text-amber-400 font-bold">5.0 ★</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

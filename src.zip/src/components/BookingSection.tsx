import React, { useState, useEffect } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { UI_TEXT, SERVICES_LIST, COMPANY_INFO } from '../i18n/translations';
import { BookingFormData, ServiceItem } from '../types';
import confetti from 'canvas-confetti';
import {
  Calendar,
  Clock,
  User,
  Mail,
  Phone,
  MessageSquare,
  CheckCircle,
  AlertCircle,
  Send,
  Sparkles,
  PhoneCall
} from 'lucide-react';

interface BookingSectionProps {
  preselectedService: ServiceItem | null;
  onClearPreselectedService: () => void;
}

export const BookingSection: React.FC<BookingSectionProps> = ({
  preselectedService,
  onClearPreselectedService,
}) => {
  const { language } = useLanguage();
  const t = UI_TEXT.booking;

  const [formData, setFormData] = useState<BookingFormData>({
    fullName: '',
    email: '',
    phone: '',
    serviceId: preselectedService ? preselectedService.id : SERVICES_LIST[0].id,
    preferredDate: '',
    preferredTime: '10:00 AM',
    notes: '',
  });

  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Sync preselected service from prop
  useEffect(() => {
    if (preselectedService) {
      setFormData((prev) => ({
        ...prev,
        serviceId: preselectedService.id,
      }));
    }
  }, [preselectedService]);

  const timeSlots = [
    '10:00 AM',
    '11:00 AM',
    '12:00 PM',
    '01:30 PM',
    '02:30 PM',
    '03:30 PM',
    '04:30 PM',
    '05:30 PM',
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    // Validation
    if (!formData.fullName.trim()) {
      setErrorMessage(language === 'ar' ? 'يرجى إدخال الاسم الكامل' : 'Please provide your full name');
      return;
    }
    if (!formData.email.trim() && !formData.phone.trim()) {
      setErrorMessage(
        language === 'ar'
          ? 'يرجى إدخال رقم الهاتف أو البريد الإلكتروني للتواصل'
          : 'Please provide either a phone number or email address'
      );
      return;
    }
    if (!formData.preferredDate) {
      setErrorMessage(language === 'ar' ? 'يرجى تحديد التاريخ المناسب' : 'Please select your preferred date');
      return;
    }

    setIsSubmitting(true);

    // Simulate reliable booking submission
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);

      // Trigger golden celebration confetti
      try {
        confetti({
          particleCount: 70,
          spread: 60,
          origin: { y: 0.6 },
          colors: ['#F59E0B', '#FBBF24', '#FCD34D', '#FFFFFF'],
        });
      } catch {
        // Safe confetti fallback
      }
    }, 400);
  };

  const selectedServiceItem = SERVICES_LIST.find((s) => s.id === formData.serviceId);

  return (
    <section id="booking" className="py-12 sm:py-16 bg-[#090D14] border-t border-slate-800 relative">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Compact Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-6 sm:mb-8 space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold uppercase tracking-wider">
            <Calendar className="w-3.5 h-3.5 text-amber-400" />
            <span>{t.badge[language]}</span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            {t.title[language]}
          </h2>

          <p className="text-xs sm:text-sm text-slate-300">
            {language === 'ar'
              ? 'احجز استشارتك المحاسبية أو الضريبية في دقيقة واحدة مع المحاسب إبراهيم'
              : 'Book your accounting or tax consultation directly in 1 minute with Accountant Ibrahim'}
          </p>
        </div>

        {/* Compact Form Card (Reduced Height, Multi-Column Layout) */}
        <div className="bg-[#0F141F] rounded-2xl border border-amber-500/30 shadow-2xl shadow-black p-5 sm:p-7 relative overflow-hidden">
          
          {isSubmitted ? (
            <div className="py-8 text-center space-y-4 animate-in zoom-in-95 duration-300">
              <div className="w-14 h-14 bg-emerald-500/10 border border-emerald-500/40 rounded-full flex items-center justify-center mx-auto text-emerald-400">
                <CheckCircle className="w-7 h-7" />
              </div>

              <div>
                <h3 className="text-xl font-bold text-white">
                  {t.successTitle[language]}
                </h3>
                <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-md mx-auto">
                  {t.successMsg[language]}
                </p>
              </div>

              <div className="inline-flex items-center gap-2 p-3 rounded-xl bg-[#141C2B] border border-amber-500/30 text-xs text-amber-300">
                <PhoneCall className="w-4 h-4 text-amber-400" />
                <span>{language === 'ar' ? 'سيتواصل معك المحاسب إبراهيم لتأكيد تفاصيل الموعد' : 'Accountant Ibrahim will reach out promptly to confirm details'}</span>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsSubmitted(false);
                    onClearPreselectedService();
                  }}
                  className="px-5 py-2 rounded-xl text-xs font-bold bg-amber-500 text-black hover:bg-amber-400 transition-all"
                >
                  {language === 'ar' ? 'حجز موعد إضافي' : 'Book Another Appointment'}
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              
              {/* Error Alert */}
              {errorMessage && (
                <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>{errorMessage}</span>
                </div>
              )}

              {/* Grid Row 1: Full Name, Phone, Email (3 columns on desktop, 1 on mobile) */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Full Name */}
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    {t.nameLabel[language]} <span className="text-amber-400">*</span>
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-400 absolute start-3 top-2.5" />
                    <input
                      type="text"
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      placeholder={t.namePlaceholder[language]}
                      className="w-full ps-9 pe-3 py-2 text-xs sm:text-sm rounded-xl bg-[#141B28] border border-slate-700/80 text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 transition-colors"
                    />
                  </div>
                </div>

                {/* Phone */}
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    {t.phoneLabel[language]} <span className="text-amber-400">*</span>
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-slate-400 absolute start-3 top-2.5" />
                    <input
                      type="tel"
                      dir="ltr"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="+1 (613) ..."
                      className="w-full ps-9 pe-3 py-2 text-xs sm:text-sm rounded-xl bg-[#141B28] border border-slate-700/80 text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 transition-colors"
                    />
                  </div>
                </div>

                {/* Email */}
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    {t.emailLabel[language]}
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute start-3 top-2.5" />
                    <input
                      type="email"
                      dir="ltr"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="your@email.com"
                      className="w-full ps-9 pe-3 py-2 text-xs sm:text-sm rounded-xl bg-[#141B28] border border-slate-700/80 text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 transition-colors"
                    />
                  </div>
                </div>
              </div>

              {/* Grid Row 2: Service Selection, Date, Time (3 columns on desktop, 1 on mobile) */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Service Selector */}
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    {t.serviceLabel[language]} <span className="text-amber-400">*</span>
                  </label>
                  <select
                    value={formData.serviceId}
                    onChange={(e) => setFormData({ ...formData, serviceId: e.target.value })}
                    className="w-full px-3 py-2 text-xs sm:text-sm rounded-xl bg-[#141B28] border border-slate-700/80 text-white focus:outline-none focus:border-amber-400 transition-colors"
                  >
                    {SERVICES_LIST.map((srv) => (
                      <option key={srv.id} value={srv.id} className="bg-slate-900 text-white">
                        #{srv.number} - {srv.title[language]}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Preferred Date */}
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    {t.dateLabel[language]} <span className="text-amber-400">*</span>
                  </label>
                  <input
                    type="date"
                    min={new Date().toISOString().split('T')[0]}
                    value={formData.preferredDate}
                    onChange={(e) => setFormData({ ...formData, preferredDate: e.target.value })}
                    className="w-full px-3 py-2 text-xs sm:text-sm rounded-xl bg-[#141B28] border border-slate-700/80 text-white focus:outline-none focus:border-amber-400 transition-colors"
                  />
                </div>

                {/* Preferred Time */}
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    {t.timeLabel[language]} <span className="text-amber-400">*</span>
                  </label>
                  <select
                    value={formData.preferredTime}
                    onChange={(e) => setFormData({ ...formData, preferredTime: e.target.value })}
                    className="w-full px-3 py-2 text-xs sm:text-sm rounded-xl bg-[#141B28] border border-slate-700/80 text-white focus:outline-none focus:border-amber-400 transition-colors"
                  >
                    {timeSlots.map((slot) => (
                      <option key={slot} value={slot} className="bg-slate-900 text-white">
                        {slot}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Notes (Optional compact row) */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  {t.notesLabel[language]} <span className="text-slate-500 font-normal">({language === 'ar' ? 'اختياري' : 'Optional'})</span>
                </label>
                <input
                  type="text"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder={t.notesPlaceholder[language]}
                  className="w-full px-3 py-2 text-xs sm:text-sm rounded-xl bg-[#141B28] border border-slate-700/80 text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 transition-colors"
                />
              </div>

              {/* Submit CTA */}
              <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3">
                <span className="text-[11px] text-slate-400">
                  {language === 'ar' ? '✓ تأكيد فوري وحفظ مباشر للبيانات' : '✓ Instant confirmation & safe data storage'}
                </span>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-7 py-2.5 rounded-xl text-xs sm:text-sm font-bold text-black bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 shadow-lg shadow-amber-500/20 active:scale-95 transition-all"
                >
                  <Send className="w-3.5 h-3.5 text-black" />
                  <span>{isSubmitting ? (language === 'ar' ? 'جاري الإرسال...' : 'Submitting...') : t.submitBtn[language]}</span>
                </button>
              </div>

            </form>
          )}

        </div>

      </div>
    </section>
  );
};
